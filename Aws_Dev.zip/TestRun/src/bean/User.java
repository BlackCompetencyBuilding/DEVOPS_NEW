package bean;

public class User {
	
	private String ID,Name,Email,Company,Password,CreationDate,CreationTime,Uname;  
	  
	public String getID() {  
	    return ID;  
	}  
	  
	public void setID(String ID) {  
	    this.ID = ID;  
	}  
	
	public String getUname() {  
	    return Uname;  
	}  
	  
	public void setUname(String Uname) {  
	    this.Uname = Uname;  
	} 
	  
	public String getName() {  
	    return Name;  
	}  
	  
	public void setName(String Name) {  
	    this.Name = Name;  
	}  
	  
	public String getEmail() {  
	    return Email;  
	}  
	  
	public void setEmail(String Email) {  
	    this.Email = Email;  
	}  
	
	public String getCompany() {  
	    return Company;  
	}  
	  
	public void setCompany(String Company) {  
	    this.Company = Company;  
	}  
	
	public String getPassword() {  
	    return Password;  
	}  
	  
	public void setPassword(String Password) {  
	    this.Password = Password;  
	}  
	
	public String getCreationDate() {  
	    return CreationDate;  
	}  
	  
	public void setCreationDate(String CreationDate) {  
	    this.CreationDate = CreationDate;  
	}  
	
	public String getCreationTime() {  
	    return CreationTime;  
	}  
	  
	public void setCreationTime(String CreationTime) {  
	    this.CreationTime = CreationTime;  
	}  

}
